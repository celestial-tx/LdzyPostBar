<template>
  <div id="app">
      <Home></Home>
  </div>
</template>

<script>
import Home from './views/Home.vue'
export default {
  name:'App',
  components: {
    Home
  }
}
</script>

<style>
#app {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
</style>
